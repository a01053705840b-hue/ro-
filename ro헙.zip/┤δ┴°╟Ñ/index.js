const {
    Client,
    GatewayIntentBits,
    PermissionsBitField,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle
} = require('discord.js');
const fs = require('fs');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

let learnedReplies = {};
let points = {};
let inventory = {};

if (fs.existsSync('./learn.json')) {
    learnedReplies = JSON.parse(fs.readFileSync('./learn.json', 'utf8'));
}

if (fs.existsSync('./points.json')) {
    points = JSON.parse(fs.readFileSync('./points.json', 'utf8'));
}

if (fs.existsSync('./inventory.json')) {
    inventory = JSON.parse(fs.readFileSync('./inventory.json', 'utf8'));
}

function saveLearn() {
    fs.writeFileSync('./learn.json', JSON.stringify(learnedReplies, null, 4));
}

function savePoints() {
    fs.writeFileSync('./points.json', JSON.stringify(points, null, 4));
}

function saveInventory() {
    fs.writeFileSync('./inventory.json', JSON.stringify(inventory, null, 4));
}

const badPatterns = [
    /시+발+/i,
    /씨+발+/i,
    /ㅅ+ㅂ+/i,
    /병+신+/i,
    /ㅂ+ㅅ+/i,
    /존+나+/i,
    /ㅈ+ㄴ+/i,
    /좆+/i,
    /지+랄+/i,
    /개+새+끼+/i,
    /씹+/i,
    /썅+/i,
    /염+병+/i,
    /호+로+/i,
    /애+미+/i
];

function normalize(text) {
    return text
        .toLowerCase()
        .replace(/[1!|lI]/g, "ㅣ")
        .replace(/[0oO]/g, "ㅇ")
        .replace(/\s/g, "")
        .replace(/[^가-힣ㄱ-ㅎㅏ-ㅣa-z0-9]/g, "");
}

// ================== 스팸(도배) 방지 ==================

const messageTimestamps = new Map(); // userId -> timestamp 배열
const SPAM_WINDOW_MS = 10000;  // 10초
const SPAM_LIMIT = 7;          // 7회 이상
const SPAM_TIMEOUT_MS = 60000; // 1분

const GACHA_COST = 100;

// ===== 가챠 확률 테이블 =====
const gachaTable = [
    { rarity: '희귀', weight: 60, items: ['일반 검', '일반 방패', '일반 부츠', '일반 짱돌'] },
    { rarity: '초희귀', weight: 28, items: ['희귀한 활', '희귀한 갑옷', '희귀한 마법서'] },
    { rarity: '영웅', weight: 9,  items: ['불꽃 검', '용의 갑옷', '반지의 제왕급'] },
    { rarity: '신화', weight: 2.5, items: ['역대급 검', '레전드 홍명보 급 축구전술'] },
    { rarity: '로헙급', weight: 0.5, items: ['로헙이의 레전드 먹다 버린 껌', '로헙이의 레전드 키우는 강아지'] }
];

// 아이템별 전투 능력치
const itemAbilities = {
    '맨손':               { power: [4, 8],   ability: null },
    '일반 검':            { power: [8, 14],  ability: null },
    '일반 방패':          { power: [5, 10],  ability: 'defense_block' },
    '일반 부츠':          { power: [5, 10],  ability: 'dodge' },
    '일반 짱돌':          { power: [6, 11],  ability: 'stun' },
    '희귀한 활':          { power: [10, 18], ability: 'crit' },
    '희귀한 갑옷':        { power: [8, 14],  ability: 'reflect' },
    '희귀한 마법서':      { power: [8, 14],  ability: 'heal' },
    '불꽃 검':            { power: [12, 20], ability: 'burn' },
    '용의 갑옷':          { power: [10, 16], ability: 'shield_passive' },
    '반지의 제왕급':      { power: [12, 20], ability: 'weaken' },
    '역대급 검':          { power: [16, 26], ability: 'crit_major' },
    '레전드 홍명보 급 축구전술': { power: [10, 20], ability: 'chaos' },
    '로헙이의 레전드 먹다 버린 껌': { power: [5, 10], ability: 'gum_skip' },
    '로헙이의 레전드 키우는 강아지': { power: [10, 18], ability: 'bite_heal' }
};

// 스킬 이름 + 설명 (한국어)
const skillInfo = {
    null:            { name: '기본공격', desc: '특수 효과 없음' },
    'defense_block': { name: '방패막기', desc: '확률적으로 받는 피해 감소' },
    'dodge':         { name: '회피', desc: '확률적으로 상대 공격을 완전히 회피' },
    'stun':          { name: '돌던지기', desc: '확률적으로 상대를 기절시켜 다음 턴 스킵' },
    'crit':          { name: '조준사격', desc: '확률적으로 치명타(피해 2배)' },
    'reflect':       { name: '피해반사', desc: '확률적으로 받은 피해 일부를 반사' },
    'heal':          { name: '회복마법', desc: '확률적으로 체력 회복' },
    'burn':          { name: '화염부여', desc: '확률적으로 상대에게 화상 효과 부여' },
    'shield_passive':{ name: '용의보호막', desc: '상시 받는 피해 20% 감소' },
    'weaken':        { name: '약화의반지', desc: '확률적으로 상대 공격력 감소' },
    'crit_major':    { name: '필살의일격', desc: '확률적으로 강력한 치명타' },
    'chaos':         { name: '홍명보전술', desc: '랜덤 효과 발동 (피해 2배 / 기절 / 회복 / 피해 감소 중 하나)' },
    'gum_skip':      { name: '껌뱉기', desc: '확률적으로 상대에게 껌을 붙여 다음 턴 스킵' },
    'bite_heal':     { name: '흡혈', desc: '피해를 입히며 그중 일부만큼 체력 흡수' }
};

const sellPrices = {
    '희귀': 20,
    '초희귀': 50,
    '영웅': 120,
    '신화': 300,
    '로헙급': 1000
};

const buyPrices = {
    '희귀': 1000,
    '초희귀': 2000,
    '영웅': 4000,
    '신화': 8000,
    '로헙급': 15000
};

function drawGacha() {
    const totalWeight = gachaTable.reduce((sum, t) => sum + t.weight, 0);
    let rand = Math.random() * totalWeight;

    for (const tier of gachaTable) {
        if (rand < tier.weight) {
            const item = tier.items[Math.floor(Math.random() * tier.items.length)];
            return { rarity: tier.rarity, item };
        }
        rand -= tier.weight;
    }
}

function getItemInfo(itemName) {
    for (const tier of gachaTable) {
        if (tier.items.includes(itemName)) {
            return { rarity: tier.rarity };
        }
    }
    return null;
}

function getSkillOf(itemName) {
    const stats = itemAbilities[itemName];
    const ability = stats ? stats.ability : null;
    return skillInfo[ability] || skillInfo[null];
}

function getOwnedItemPool(uid) {
    const inv = inventory[uid] || {};
    const pool = Object.keys(inv).filter(name => inv[name] > 0);
    return pool.length > 0 ? pool : ['맨손'];
}

function shuffleArray(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function getTitle(uid) {
    const ranking = Object.entries(points).sort((a, b) => b[1].point - a[1].point);
    const rank = ranking.findIndex(([id]) => id === uid) + 1;

    let rankTitle = '일반인';
    if (rank === 1) rankTitle = '서버1등';
    else if (rank >= 2 && rank <= 3) rankTitle = '서버2등';
    else if (rank >= 4 && rank <= 10) rankTitle = '서버3등';

    const myItems = inventory[uid] || {};
    const rarityOrder = ['희귀', '초희귀', '영웅', '신화', '로헙급'];
    let bestRarity = null;

    for (const itemName of Object.keys(myItems)) {
        if (myItems[itemName] <= 0) continue;
        const info = getItemInfo(itemName);
        if (!info) continue;
        if (!bestRarity || rarityOrder.indexOf(info.rarity) > rarityOrder.indexOf(bestRarity)) {
            bestRarity = info.rarity;
        }
    }

    let itemTitle = '';
    if (bestRarity === '로헙급') itemTitle = '로헙급 소유자';
    else if (bestRarity === '신화') itemTitle = '신화급 소유자';
    else if (bestRarity === '영웅') itemTitle = '영웅급 소유자';
    else if (bestRarity) itemTitle = '초짜';

    return { rankTitle, itemTitle, rank };
}

// ================== 상점 시스템 ==================

const SHOP_RESET_MS = 60 * 60 * 1000; // 1시간
let currentShop = null; // { items: [{name, rarity}], generatedAt }

function getAllShopCandidates() {
    const list = [];
    for (const tier of gachaTable) {
        for (const item of tier.items) {
            list.push({ name: item, rarity: tier.rarity });
        }
    }
    return list;
}

function generateShop() {
    const candidates = shuffleArray(getAllShopCandidates());
    const items = candidates.slice(0, 4);
    currentShop = {
        items,
        generatedAt: Date.now()
    };
    return currentShop;
}

function getShop() {
    if (!currentShop || Date.now() - currentShop.generatedAt >= SHOP_RESET_MS) {
        generateShop();
    }
    return currentShop;
}

// ================== 전투 시스템 (턴제, 랜덤 스킬 선택형) ==================

const activeBattles = new Map(); // key: channelId
const pendingChallenges = new Map(); // key: channelId, 수락/거절 대기중인 신청
const MAX_CHOICES = 3; // 매턴 랜덤으로 보여줄 아이템(스킬) 개수

function code(text) {
    return '```\n' + text + '\n```';
}

function makeFighter(userId, username) {
    const pool = getOwnedItemPool(userId);
    return {
        id: userId,
        username,
        itemPool: pool,
        item: pool[0],
        hp: 100,
        atkMod: 0,
        stunned: false,
        burnTurns: 0,
        defending: false
    };
}

// 공격 처리 (선택한 아이템으로 항상 그 아이템의 스킬 판정 포함)
function resolveAttack(attacker, defender) {
    const stats = itemAbilities[attacker.item] || { power: [4, 8], ability: null };
    const defStats = itemAbilities[defender.item] || { power: [4, 8], ability: null };
    const skill = getSkillOf(attacker.item);

    const log = [];
    log.push(`사용아이템: ${attacker.item}`);
    log.push(`사용스킬: ${skill.name}`);

    // 방어자의 회피(수동 특성) 체크
    if (defStats.ability === 'dodge' && Math.random() < 0.3) {
        log.push(`결과: 빗나감`);
        log.push(`대상: ${defender.username} 회피_성공`);
        return log;
    }

    const [min, max] = stats.power;
    let damage = Math.max(1, Math.floor(Math.random() * (max - min + 1)) + min + attacker.atkMod);
    let selfHeal = 0;
    let stunTarget = false;
    let burnTarget = false;
    let weakenTarget = false;
    let reflectDamage = 0;

    switch (stats.ability) {
        case 'crit':
            if (Math.random() < 0.25) {
                damage *= 2;
                log.push(`스킬효과: 치명타_발동`);
            }
            break;
        case 'crit_major':
            if (Math.random() < 0.18) {
                damage = Math.floor(damage * 2.2);
                log.push(`스킬효과: 강력한_치명타_발동`);
            }
            break;
        case 'stun':
            if (Math.random() < 0.25) {
                stunTarget = true;
                log.push(`스킬효과: 기절_적용`);
            }
            break;
        case 'burn':
            if (Math.random() < 0.3) {
                burnTarget = true;
                log.push(`스킬효과: 화상_적용`);
            }
            break;
        case 'weaken':
            if (Math.random() < 0.3) {
                weakenTarget = true;
                log.push(`스킬효과: 공격력_감소_적용`);
            }
            break;
        case 'heal':
            if (Math.random() < 0.3) {
                selfHeal = 12;
                log.push(`스킬효과: 체력_회복 +12`);
            }
            break;
        case 'bite_heal':
            selfHeal = Math.floor(damage * 0.4);
            log.push(`스킬효과: 흡혈 +${selfHeal}`);
            break;
        case 'gum_skip':
            if (Math.random() < 0.4) {
                stunTarget = true;
                damage = Math.floor(damage * 0.5);
                log.push(`스킬효과: 턴_스킵_적용`);
            }
            break;
        case 'defense_block':
            break;
        case 'chaos': {
            const roll = Math.random();
            if (roll < 0.25) {
                damage *= 2;
                log.push(`스킬효과: 랜덤결과=피해량_2배`);
            } else if (roll < 0.5) {
                stunTarget = true;
                log.push(`스킬효과: 랜덤결과=기절`);
            } else if (roll < 0.75) {
                selfHeal = 15;
                log.push(`스킬효과: 랜덤결과=회복+15`);
            } else {
                damage = Math.floor(damage * 0.3);
                log.push(`스킬효과: 랜덤결과=피해량_감소`);
            }
            break;
        }
        default:
            break;
    }

    // 방어자 방어 선택 시 50% 감소 (유일한 방어 효과)
    if (defender.defending) {
        damage = Math.floor(damage * 0.5);
        log.push(`방어보너스: ${defender.username} 피해량_50%_감소`);
    }

    // 방어자 수동 특성
    if (defStats.ability === 'defense_block' && Math.random() < 0.35) {
        damage = Math.floor(damage * 0.5);
        log.push(`패시브: ${defender.username} 방패막기_발동`);
    }
    if (defStats.ability === 'shield_passive') {
        damage = Math.floor(damage * 0.8);
    }
    if (defStats.ability === 'reflect' && Math.random() < 0.25) {
        reflectDamage = Math.floor(damage * 0.5);
        log.push(`패시브: ${defender.username} 피해반사_발동`);
    }

    log.push(`가한피해: ${damage}`);

    defender.hp -= damage;
    attacker.hp = Math.min(100, attacker.hp + selfHeal);
    if (stunTarget) defender.stunned = true;
    if (burnTarget) defender.burnTurns = 2;
    if (weakenTarget) defender.atkMod -= 4;
    attacker.hp -= reflectDamage;

    if (selfHeal > 0) {
        log.push(`자가회복_적용: +${selfHeal}`);
    }
    if (reflectDamage > 0) {
        log.push(`반사피해_받음: ${reflectDamage}`);
    }

    return log;
}

async function runBattle(message, p1, p2, betAmount) {

    const battleKey = message.channel.id;
    activeBattles.set(battleKey, true);

    const startMsg =
`전투_시작
플레이어1: ${p1.username} | 보유아이템수: ${p1.itemPool.length} | 체력: ${p1.hp}
플레이어2: ${p2.username} | 보유아이템수: ${p2.itemPool.length} | 체력: ${p2.hp}
베팅: ${betAmount}P
최대턴수: 20`;

    await message.channel.send(code(startMsg));

    let turnCount = 0;
    let winner = null;

    while (turnCount < 20) {
        turnCount++;

        const attacker = turnCount % 2 === 1 ? p1 : p2;
        const defender = turnCount % 2 === 1 ? p2 : p1;

        attacker.defending = false;

        // 화상 데미지 처리
        if (attacker.burnTurns > 0) {
            attacker.hp -= 5;
            attacker.burnTurns--;
            await message.channel.send(code(
`턴 ${turnCount}
상태이상: 화상
대상: ${attacker.username}
피해량: 5
체력_${attacker.username}: ${Math.max(0, attacker.hp)}`
            ));
        }

        if (attacker.hp <= 0 || defender.hp <= 0) break;

        if (attacker.stunned) {
            attacker.stunned = false;
            await message.channel.send(code(
`턴 ${turnCount}
차례: ${attacker.username}
상태: 기절
행동: 스킵됨`
            ));
            continue;
        }

        // 매턴 랜덤으로 보유 아이템 중 일부(최대 MAX_CHOICES개)를 뽑아 선택지 제시
        const shuffled = shuffleArray(attacker.itemPool);
        const choices = shuffled.slice(0, Math.min(MAX_CHOICES, shuffled.length));

        // 방어는 항상 "4"번으로 고정
        let optionLines = choices.map((itemName, idx) => {
            const skill = getSkillOf(itemName);
            return `${idx + 1} = ${itemName} 사용 (스킬: ${skill.name} - ${skill.desc})`;
        });
        optionLines.push(`4 = 방어 (50% 피해감소)`);

        const validInputs = choices.map((_, idx) => String(idx + 1));
        validInputs.push('4');

        const prompt =
`턴 ${turnCount}
차례: ${attacker.username}
체력_${p1.username}: ${Math.max(0, p1.hp)} | 체력_${p2.username}: ${Math.max(0, p2.hp)}
행동선택:
${optionLines.join('\n')}
입력제한시간: 30초`;

        await message.channel.send(code(prompt));

        let chosenIndex = 0; // 기본값: 첫번째 아이템 사용
        let isDefend = false;

        try {
            const collected = await message.channel.awaitMessages({
                filter: m => m.author.id === attacker.id && validInputs.includes(m.content.trim()),
                max: 1,
                time: 30000,
                errors: ['time']
            });

            const input = collected.first().content.trim();

            if (input === '4') {
                isDefend = true;
            } else {
                chosenIndex = parseInt(input) - 1;
            }

        } catch (e) {
            await message.channel.send(code(
`턴 ${turnCount}
입력시간_초과
기본행동_적용: ${choices[0]} 사용`
            ));
        }

        let log;

        if (isDefend) {
            attacker.defending = true;
            log = [`행동: 방어`, `상태: ${attacker.username} 50% 피해감소`];
        } else {
            attacker.item = choices[chosenIndex];
            log = resolveAttack(attacker, defender);
        }

        await message.channel.send(code(
`턴 ${turnCount}_결과
${log.join('\n')}
체력_${p1.username}: ${Math.max(0, p1.hp)} | 체력_${p2.username}: ${Math.max(0, p2.hp)}`
        ));

        if (p1.hp <= 0 || p2.hp <= 0) break;
    }

    p1.hp = Math.max(0, p1.hp);
    p2.hp = Math.max(0, p2.hp);

    if (p1.hp <= 0 && p2.hp <= 0) {
        winner = null;
    } else if (p1.hp <= 0) {
        winner = p2;
    } else if (p2.hp <= 0) {
        winner = p1;
    } else {
        winner = p1.hp >= p2.hp ? p1 : p2;
    }

    let resultMsg = `전투_종료\n체력_${p1.username}: ${p1.hp} | 체력_${p2.username}: ${p2.hp}\n`;

    if (!winner) {
        resultMsg += `결과: 무승부`;
    } else {
        const loser = winner.id === p1.id ? p2 : p1;
        resultMsg += `승리자: ${winner.username}\n패배자: ${loser.username}`;

        // 배팅금이 있으면 그 금액만큼, 없으면 기본 300P 이동 (부족해도 마이너스 허용)
        const STEAL_AMOUNT = betAmount > 0 ? betAmount : 300;
        points[winner.id].point += STEAL_AMOUNT;
        points[loser.id].point -= STEAL_AMOUNT;
        savePoints();
        resultMsg += `\n포인트_이동: ${STEAL_AMOUNT}P (${loser.username} -> ${winner.username})`;
    }

    await message.channel.send(code(resultMsg));

    activeBattles.delete(battleKey);
}

client.once('ready', () => {
    console.log(`${client.user.tag} 온라인`);
});

client.on('messageCreate', async (message) => {

    if (message.author.bot) return;

    const userId = message.author.id;

    // ===== 스팸(도배) 감지: 10초 내 7회 이상 메시지 시 1분 타임아웃 =====
    const now = Date.now();
    const recentTimestamps = (messageTimestamps.get(userId) || []).filter(t => now - t < SPAM_WINDOW_MS);
    recentTimestamps.push(now);
    messageTimestamps.set(userId, recentTimestamps);

    if (recentTimestamps.length >= SPAM_LIMIT) {
        messageTimestamps.set(userId, []);

        const member = message.member;

        if (member && member.moderatable) {
            await member.timeout(SPAM_TIMEOUT_MS, '10초 내 7회 이상 메시지 도배').catch(() => {});
            await message.channel.send(`${message.author} 님이 도배로 인해 1분간 타임아웃되었습니다.`).catch(() => {});
        }

        return;
    }

    if (!points[userId]) {
        points[userId] = {
            point: 0,
            lastAttendance: null
        };
    }

    points[userId].point += 1;
    savePoints();

    const text = normalize(message.content);

    for (const pattern of badPatterns) {
        if (pattern.test(text)) {
            await message.delete().catch(() => {});
            return;
        }
    }

    if (message.content === '!포인트') {
        return message.reply(
            `현재 포인트: ${points[userId].point}P`
        );
    }

    if (message.content === '!출석') {

        const today = new Date().toDateString();

        if (points[userId].lastAttendance === today) {
            return message.reply('이미 출석했습니다.');
        }

        points[userId].lastAttendance = today;
        points[userId].point += 100;

        savePoints();

        return message.reply(
            `출석 완료\n현재 포인트: ${points[userId].point}P`
        );
    }

    if (message.content === '!포인트얻기') {

        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('관리자만 사용할 수 있습니다.');
        }

        points[userId].point += 10000;
        savePoints();

        return message.reply(
            `10000P 지급 완료\n현재 포인트: ${points[userId].point}P`
        );
    }

    if (message.content.startsWith('!공지')) {

        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply('관리자만 사용할 수 있습니다.');
        }

        const content = message.content.slice('!공지'.length).trim();

        if (!content) {
            return message.reply('사용법: !공지 [내용]');
        }

        const embed = new EmbedBuilder()
            .setTitle('공지사항')
            .setDescription(content)
            .setColor(0xFFD700)
            .setFooter({ text: `작성자: ${message.author.username}` })
            .setTimestamp();

        return message.channel.send({ embeds: [embed] });
    }

    if (message.content.startsWith('!송금')) {

        const target = message.mentions.users.first();

        if (!target) {
            return message.reply('유저를 멘션하세요.');
        }

        const amount = parseInt(message.content.split(' ')[2]);

        if (isNaN(amount) || amount <= 0) {
            return message.reply('금액을 입력하세요.');
        }

        if (points[userId].point < amount) {
            return message.reply('포인트가 부족합니다.');
        }

        if (!points[target.id]) {
            points[target.id] = {
                point: 0,
                lastAttendance: null
            };
        }

        points[userId].point -= amount;
        points[target.id].point += amount;

        savePoints();

        return message.reply(
            `${target.username}님에게 ${amount}P 송금했습니다.`
        );
    }

    if (message.content === '!랭킹') {

        const ranking = Object.entries(points)
            .sort((a, b) => b[1].point - a[1].point)
            .slice(0, 10);

        let msg = '포인트 랭킹\n\n';

        for (let i = 0; i < ranking.length; i++) {

            const user = await client.users
                .fetch(ranking[i][0])
                .catch(() => null);

            if (!user) continue;

            msg += `${i + 1}위 - ${user.username} : ${ranking[i][1].point}P\n`;
        }

        return message.channel.send(msg);
    }

    if (message.content === '!칭호') {

        const { rankTitle, itemTitle, rank } = getTitle(userId);

        let msg = `${message.author.username}님의 칭호\n\n`;
        msg += `순위: ${rank}위 - ${rankTitle}\n`;
        if (itemTitle) {
            msg += `아이템: ${itemTitle}\n`;
        }

        return message.reply(msg);
    }

    if (message.content === '!뽑기') {

        if (points[userId].point < GACHA_COST) {
            return message.reply(`포인트가 부족합니다. (필요: ${GACHA_COST}P)`);
        }

        points[userId].point -= GACHA_COST;
        savePoints();

        const result = drawGacha();

        if (!inventory[userId]) {
            inventory[userId] = {};
        }

        inventory[userId][result.item] = (inventory[userId][result.item] || 0) + 1;
        saveInventory();

        return message.reply(
            `[${result.rarity}] ${result.item} 획득\n남은 포인트: ${points[userId].point}P`
        );
    }

    if (message.content === '!인벤토리') {

        const myItems = inventory[userId];

        if (!myItems || Object.keys(myItems).length === 0) {
            return message.reply('보유한 아이템이 없습니다. !뽑기로 아이템을 획득해보세요.');
        }

        let msg = '보유 아이템\n\n';

        for (const [item, count] of Object.entries(myItems)) {
            const skill = getSkillOf(item);
            msg += `- ${item} x${count} (스킬: ${skill.name})\n`;
        }

        return message.reply(msg);
    }

    if (message.content.startsWith('!판매')) {

    let rest = message.content.slice('!판매'.length).trim();

    if (!rest) {
        return message.reply('사용법: !판매 [아이템명] [개수]');
    }

    let count = 1;

    // 끝에 x11, X11, *11, 11 형식 찾기
    const amountMatch = rest.match(/(?:\s+|)(?:x|\*|X)?(\d+)$/);

    if (amountMatch) {
        count = parseInt(amountMatch[1]);

        // 개수 부분 제거
        rest = rest.substring(0, amountMatch.index).trim();

        if (count <= 0) count = 1;
    }

    const myItems = inventory[userId] || {};
    const ownedNames = Object.keys(myItems).sort((a, b) => b.length - a.length);

    let matchedItem = null;

    for (const name of ownedNames) {
        if (rest === name) {
            matchedItem = name;
            break;
        }
    }

    if (!matchedItem) {
        return message.reply('보유하지 않은 아이템이거나 이름이 정확하지 않습니다. !인벤토리로 확인해보세요.');
    }

    if (!myItems[matchedItem] || myItems[matchedItem] < count) {
        return message.reply(`보유 수량이 부족합니다. (보유: ${myItems[matchedItem] || 0}개)`);
    }

    const info = getItemInfo(matchedItem);
    const price = info ? (sellPrices[info.rarity] || 10) : 10;
    const totalGain = price * count;

    myItems[matchedItem] -= count;

    if (myItems[matchedItem] <= 0) {
        delete myItems[matchedItem];
    }

    saveInventory();

    points[userId].point += totalGain;
    savePoints();

    return message.reply(
        `${matchedItem} ${count}개를 판매하여 ${totalGain}P를 획득했습니다.\n현재 포인트: ${points[userId].point}P`
    );
}

    // ===== 상점 =====
    if (message.content === '!상점') {

        const shop = getShop();
        const remainMs = SHOP_RESET_MS - (Date.now() - shop.generatedAt);
        const remainMin = Math.max(0, Math.ceil(remainMs / 60000));

        let listMsg = `상점 (남은시간: 약 ${remainMin}분 후 리셋)\n\n`;

        const row = new ActionRowBuilder();

        shop.items.forEach((item, idx) => {
            const price = buyPrices[item.rarity] || 100;
            listMsg += `${idx + 1}. [${item.rarity}] ${item.name} - ${price}P\n`;

            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`shopbuy_${idx}_${shop.generatedAt}`)
                    .setLabel(`${idx + 1}. ${item.name} (${price}P)`)
                    .setStyle(ButtonStyle.Primary)
            );
        });

        return message.channel.send({
            content: code(listMsg),
            components: [row]
        });
    }

    if (message.content.startsWith('!전투')) {

        const target = message.mentions.users.first();

        if (!target) {
            return message.reply('사용법: !전투 @상대 [베팅포인트]');
        }

        if (target.id === userId) {
            return message.reply('자기 자신과는 싸울 수 없습니다.');
        }

        if (target.bot) {
            return message.reply('봇과는 싸울 수 없습니다.');
        }

        if (activeBattles.has(message.channel.id) || pendingChallenges.has(message.channel.id)) {
            return message.reply('이 채널에서 이미 전투(또는 신청)가 진행 중입니다.');
        }

        if (!points[target.id]) {
            points[target.id] = { point: 0, lastAttendance: null };
        }

        const rest = message.content
            .slice('!전투'.length)
            .replace(/<@!?\d+>/g, '')
            .trim();

        // 숫자만 뽑아서 베팅액 파싱 (숨은 특수문자 등으로 인한 파싱 실패 방지)
        const betMatch = rest.match(/\d+/);
        let betAmount = betMatch ? parseInt(betMatch[0]) : 0;
        if (isNaN(betAmount) || betAmount <= 0) betAmount = 0;

        if (betAmount > 0 && (betAmount > points[userId].point || betAmount > points[target.id].point)) {
            return message.reply('둘 중 한 명의 포인트가 베팅 금액보다 부족합니다.');
        }

        // ===== 전투 신청: 수락/거절 대기 =====
        pendingChallenges.set(message.channel.id, true);

        await message.channel.send(code(
`전투_신청
신청자: ${message.author.username}
대상: ${target.username}
베팅: ${betAmount}P
${target.username}님, "수락" 또는 "거절"을 입력해주세요. (30초, 미응답 시 자동 거절)`
        ));

        let accepted = false;

        try {
            const collected = await message.channel.awaitMessages({
                filter: m => m.author.id === target.id && ['수락', '거절'].includes(m.content.trim()),
                max: 1,
                time: 30000,
                errors: ['time']
            });

            accepted = collected.first().content.trim() === '수락';

        } catch (e) {
            accepted = false;
        }

        if (!accepted) {
            pendingChallenges.delete(message.channel.id);
            return message.channel.send(code(
`전투_신청_거절
${target.username}님이 전투를 거절했거나 30초 내 응답하지 않았습니다.`
            ));
        }

        pendingChallenges.delete(message.channel.id);

        const p1 = makeFighter(userId, message.author.username);
        const p2 = makeFighter(target.id, target.username);

        return runBattle(message, p1, p2, betAmount);
    }

    if (message.mentions.has(client.user)) {

        const content = message.content
            .replace(`<@${client.user.id}>`, '')
            .replace(`<@!${client.user.id}>`, '')
            .trim();

        const args = content.split(' ');

        if (args[0] === '가르치기') {

            const trigger = args[1];
            const reply = args.slice(2).join(' ');

            if (!trigger || !reply) return;

            learnedReplies[trigger] = reply;

            saveLearn();

            return message.reply('배웠습니다.');
        }

        if (args[0] === '잊기') {

            const trigger = args[1];

            if (!trigger) {
                return message.reply('잊을 트리거를 입력하세요.');
            }

            if (!learnedReplies[trigger]) {
                return message.reply('그런 트리거는 배운 적이 없습니다.');
            }

            delete learnedReplies[trigger];

            saveLearn();

            return message.reply(`"${trigger}" 를 잊었습니다.`);
        }
    }

    if (learnedReplies[message.content]) {
        return message.channel.send(
            learnedReplies[message.content]
        );
    }

});

// ===== 상점 구매 버튼 처리 =====
client.on('interactionCreate', async (interaction) => {

    if (!interaction.isButton()) return;

    if (!interaction.customId.startsWith('shopbuy_')) return;

    const [, idxStr, genAtStr] = interaction.customId.split('_');
    const idx = parseInt(idxStr);
    const genAt = parseInt(genAtStr);

    const shop = getShop();

    // 버튼이 눌린 시점 기준으로 상점이 이미 리셋됐는지 확인
    if (!currentShop || currentShop.generatedAt !== genAt) {
        return interaction.reply({
            content: '상점이 이미 리셋되어 이 버튼은 더 이상 유효하지 않습니다. !상점으로 다시 확인해주세요.',
            ephemeral: true
        });
    }

    const item = shop.items[idx];

    if (!item) {
        return interaction.reply({ content: '잘못된 상품입니다.', ephemeral: true });
    }

    const buyerId = interaction.user.id;

    if (!points[buyerId]) {
        points[buyerId] = { point: 0, lastAttendance: null };
    }

    const price = buyPrices[item.rarity] || 100;

    if (points[buyerId].point < price) {
        return interaction.reply({
            content: `포인트가 부족합니다. (필요: ${price}P / 보유: ${points[buyerId].point}P)`,
            ephemeral: true
        });
    }

    points[buyerId].point -= price;
    savePoints();

    if (!inventory[buyerId]) inventory[buyerId] = {};
    inventory[buyerId][item.name] = (inventory[buyerId][item.name] || 0) + 1;
    saveInventory();

    return interaction.reply({
        content: `[${item.rarity}] ${item.name} 구매 완료! (-${price}P)\n남은 포인트: ${points[buyerId].point}P`,
        ephemeral: true
    });
});

client.login('MTQ5MTA0NjQzNTc5MjIyODQwMg.GkLWR2.eilLpF-7MFCWMh5zv6Syk5R3LKgx69_Xfg637o');